var newlinkele=document.createElement("link")
newlinkele.rel="prefetch"
newlinkele.href="sidebar.md"
document.head.appendChild(newlinkele)
newlinkele=null
var newlinkele=document.createElement("link")
newlinkele.rel="prefetch"
newlinkele.href="README.md"
document.head.appendChild(newlinkele)
newlinkele=null