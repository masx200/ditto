Parcel 是一个 web 应用打包工具, 与其他工具的区别在于开发者的使用体验。它利用多核处理器提供了极快的速度, 并且不需要任何配置。

npm install -g parcel-bundler

parcel  index.html --open

parcel build index.html  --public-url ./