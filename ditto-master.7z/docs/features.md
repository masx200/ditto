# Features

- Embed Youtube videos


## Embed Youtube videos

Use `[ditto:youtube:<youtube url>]` to embed youtube videos:
```javascript
 [ditto:youtube:https://www.youtube.com/watch?v=9CS7j5I6aOc] 
```